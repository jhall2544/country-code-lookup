const countryCodes = {
  "1": "United States/Canada",
  "44": "United Kingdom",
  "91": "India",
  "81": "Japan",
  "49": "Germany",
  "33": "France",
  "61": "Australia",
  "86": "China",
  "39": "Italy",
  "7": "Russia"
};